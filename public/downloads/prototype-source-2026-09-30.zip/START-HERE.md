# 多元拾光原型交付包 · 2026-09-30

这是当前评审中的 React / TypeScript 原型源码，不是 Figma 设计文件，也不是已经接入后端的生产系统。

## 打开方式
1. 下载源码包并解压。
2. 安装 Node.js 22.13 或更新版本，在包含 package.json 的目录执行 npm ci。
3. 执行 node scripts/restore-prototype-assets.mjs 补齐素材（需要联网），再执行 npm run dev，打开 http://127.0.0.1:3000/community-options/prototype-review 。
4. 不需要账号、生产 API Key 或线上数据。交互采用浏览器本地演示状态。

## 设计与研发入口
- app/community-options/prototype-review/：页面目录、需求、流程、评审状态。
- app/community-options/c-prototype/：C 端组件与 CSS。
- app/community-options/b-prototype/：B 端组件与演示配置。
- app/community-options/cross-prototype/：MakeNow 等跨产品承接演示。
- app/community-options/mobile-home/、home-prototype/：移动与 PC 首页。
- design-notes/requirements-*.md：页面需求。
- public/：图片、视频和图标。脚本从本次发布的无损素材恢复原型路径，不裁切、不降低尺寸或像素质量；重新编码后的图片不承诺与原始文件字节相同。

轻创作保留在社区；AI 应用仅作发现、介绍，使用统一由 MakeNow 承接。MakeNow 定向链接尚未配置，跨产品页面为演示。
本包以 C/B/跨产品原型为交付范围；为保留编译依赖附带研究站源代码，但历史研究报告的图片、附件与旧方案素材不全量打包。请从上述原型评审入口开始。
版本仍在评审，界面内的“已完成/待确认/待评审”状态保留，不代表全量产品定稿。
