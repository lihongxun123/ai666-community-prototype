'use client';
import {ResearchOutline,ResearchAppendix} from './research-outline';
import {ConditionReview} from '@/components/research-completion';
import {useMemo,useState} from 'react';
import raw from '@/lib/china-ai-users.json';
import './china-ai-users.css';

type Source={id:string;title:string;publisher:string;url:string;publishedAt:string|null;scope:string;method:string;locator:string};
type Metric={id:string;metric:string;value:number;unit:string;period:string;publishedAt:string;universe:string;denominator:string;method:string;limitation:string;sourceIds:string[];family:string;evidenceStatus:string;display?:string;sample?:string;group?:string};
type Paragraph={text:string;sourceIds:string[];kind:string};
type Table={title:string;headers:string[];rows:string[][];sourceIds:string[];note:string};
type Section={id:string;title:string;paragraphs:Paragraph[];tables:Table[]};
type Dataset=Omit<typeof raw,'metrics'|'sources'|'sections'> & {metrics:Metric[];sources:Source[];sections:Section[]};
const data=raw as unknown as Dataset;
const chapterGroups=[
 {id:'national',title:'全国规模',ids:['answer','scope','growth']},
 {id:'usage',title:'用户构成与使用情况',ids:['people','purpose','entry','frequency','work']},
 {id:'payment',title:'付费用户',ids:['payers']},
 {id:'analysis',title:'使用方式与内容需要',ids:['ways','tasks','gaps']},
];
const sourceMap=new Map(data.sources.map(s=>[s.id,s]));
const showMetric=(m:Metric)=>m.display||`${m.value.toLocaleString('zh-CN',{maximumFractionDigits:2})}${m.unit}`;

function go(id:string){const target=document.getElementById(`cn-${id}`);if(!target)return;
 for(let node=target.parentElement;node;node=node.parentElement)if(node instanceof HTMLDetailsElement)node.open=true;
 target.scrollIntoView({behavior:'smooth',block:'start'});target.focus({preventScroll:true});
}
function References({ids}:{ids:string[]}){return ids.length?<span className="cn-refs">{ids.map(id=>{const source=sourceMap.get(id);return source?<a key={id} href={`#cn-source-${id}`} onClick={e=>{e.preventDefault();go(`source-${id}`);}} title={`${source.title} · ${source.publishedAt}`}>{source.publisher.split('；')[0]}来源</a>:null;})}</span>:null;}
function DataTable({table}:{table:Table}){return <div className="cn-table-block"><h3>{table.title}</h3><div className="cn-scroll" tabIndex={0} role="region" aria-label={table.title}><table><thead><tr>{table.headers.map(h=><th scope="col" key={h}>{h}</th>)}</tr></thead><tbody>{table.rows.map((row,i)=><tr key={i}>{row.map((cell,j)=>j===0?<th scope="row" key={j}>{cell}</th>:<td key={j}>{cell}</td>)}</tr>)}</tbody></table></div>{table.note&&<p className="cn-caption">{table.note}</p>}<References ids={table.sourceIds}/></div>;}

function NationalChart(){return <figure className="cn-chart"><figcaption><h3>全国生成式AI使用者</h3><p>单位：亿人。每个时点为调查估计；2026年数据未取得。</p></figcaption><div className="cn-trend">{data.nationalTrend.map(t=><div key={t.period} className={`cn-trend-item ${t.users===null?'cn-unavailable':''}`}><div className="cn-bar-space">{t.users!==null?<><strong>{t.users/1e8}<small>亿</small></strong><span className="cn-column" style={{height:`${t.users/602000000*135}px`}}/></>:<strong>未取得</strong>}</div><b>{t.period}</b><small>{t.populationPenetration===null?'不外推':`人口普及率 ${t.populationPenetration}%`}</small></div>)}</div><p className="cn-caption">2024年历史问卷的完整回忆期未取得。半年用户、月活和日活不合并为同一序列。</p><References ids={['N24-S09','N24-S10','N24-S06','N24-S04','N24-S02']}/></figure>;}

function PurposeChart(){const [counts,setCounts]=useState(false);return <figure className="cn-chart"><figcaption><h3>全国AI用户的七种用途</h3><p>2025年12月；多选，分母为本期生成式AI用户。横条统一按0—100%绘制。</p></figcaption><label className="cn-check"><input type="checkbox" checked={counts} onChange={e=>setCounts(e.target.checked)}/>同时查看两项用途的估算人数</label><div className="cn-bars">{data.purposes.map(m=><div className="cn-bar-row" key={m.id}><div><span>{m.metric}</span><strong>{m.value}%</strong></div><div className="cn-track"><span style={{width:`${m.value}%`}}/></div>{counts&&['SEG24-M25','SEG24-M30'].includes(m.id)&&<small className="cn-derived">报告计算：{m.id==='SEG24-M25'?'6.02亿 × 47.8% ≈ 2.88亿人':'6.02亿 × 10.8% ≈ 6500万人'}用途覆盖，不是职业人数。</small>}</div>)}</div><p className="cn-caption">同一人可以出现在多项中，不加总。图像/视频用途包含“处理”，不能全部计为专业生成创作。</p><References ids={['N24-S02']}/></figure>;}

function MobileChart(){return <figure className="cn-chart"><figcaption><h3>AI原生App整体月活</h3><p>QuestMobile；独立于全国调查序列。单位：亿。</p></figcaption><div className="cn-bars">{data.mobileTrend.map(m=><div className="cn-bar-row" key={m.id}><div><span>{m.period}</span><strong>{m.value}亿</strong></div><div className="cn-track cn-mobile-track"><span style={{width:`${m.value/5*100}%`}}/></div></div>)}</div><p className="cn-caption">横条上限5亿，仅比较三个同类时点。样本、跨设备匹配和误差未完整公开；不与全国人数相减。</p><References ids={['MB24-S05','MB24-S03','MB24-S01']}/></figure>;}

function Ways(){const [current,setCurrent]=useState(data.layers[0].id);const selected=data.layers.find(x=>x.id===current)!;return <div className="cn-selector"><p className="cn-label">分析框架 · 不作高低排序 · 各层全国人数未取得</p><div className="cn-options" role="group" aria-label="选择一种使用方式">{data.layers.map(x=><button key={x.id} aria-pressed={current===x.id} onClick={()=>setCurrent(x.id)}>{x.name}</button>)}</div><div className="cn-selected" aria-live="polite"><h3>{selected.name}</h3><p>{selected.criterion}</p><p className="cn-example">例如：{selected.example}</p><dl>{[['核心需要',selected.need],['内容承诺',selected.content],['供给责任',selected.operator],['工具关系',selected.tool],['需要反证',selected.counter],['人数边界',selected.size]].map(([label,text])=><div key={label}><dt>{label}</dt><dd>{text}</dd></div>)}</dl></div><p className="cn-caption">使用方式可重叠，尚无全国占比。</p></div>;}

function TaskProfiles(){const [current,setCurrent]=useState('visual');const selected=data.taskSegments.find(x=>x.id===current)!;return <div className="cn-selector"><div className="cn-options" role="group" aria-label="按任务查看内容需求">{data.taskSegments.map(x=><button key={x.id} aria-pressed={current===x.id} onClick={()=>setCurrent(x.id)}>{x.name}</button>)}</div><div className="cn-selected" aria-live="polite"><p className="cn-label">任务划分（分析）· 可重叠 · 尚无对应人群的全国统计</p><h3>{selected.name}</h3><p>{selected.task}</p><dl>{[['任务触发',selected.trigger],['核心需要',selected.need],['内容形态',selected.format],['回访理由（假设）',selected.return],['替代方式',selected.alternative],['工具关系',selected.toolFit],['供给责任',selected.supply],['证据边界',selected.evidence]].map(([label,text])=><div key={label}><dt>{label}</dt><dd>{text}</dd></div>)}</dl></div></div>;}

function EvidenceLedger(){const [family,setFamily]=useState('全部');const [query,setQuery]=useState('');const [expanded,setExpanded]=useState(false);
 const allowed=data.metrics.filter(x=>x.evidenceStatus!=='排除主表');
 const filtered=useMemo(()=>allowed.filter(x=>(family==='全部'||x.family===family)&&`${x.metric} ${x.period} ${x.universe} ${x.group||''}`.toLowerCase().includes(query.trim().toLowerCase())),[allowed,family,query]);
 return <section id="cn-ledger" tabIndex={-1} className="cn-section"><h2>指标与方法台账</h2><p>{data.metrics.length}项指标，含4项未采用记录。</p><div className="cn-ledger-filters"><label>数据类型<select value={family} onChange={e=>{setFamily(e.target.value);setExpanded(false);}}><option>全部</option>{[...new Set(allowed.map(x=>x.family))].map(x=><option key={x}>{x}</option>)}</select></label><label>查找指标<input value={query} onChange={e=>{setQuery(e.target.value);setExpanded(false);}} placeholder="例如：付费、年龄、2026-06"/></label><span aria-live="polite">{filtered.length}条</span></div><div className="cn-ledger-list">{(expanded?filtered:filtered.slice(0,12)).map(m=><details key={m.id}><summary><span>{m.metric}<small>{m.period} · {m.family} · {m.evidenceStatus}</small></span><strong>{showMetric(m)}</strong></summary><dl>{[['对象',m.universe],['分母',m.denominator],['方法',m.method],['样本',m.sample],['限制',m.limitation],['发布',m.publishedAt]].filter(([,v])=>v).map(([label,value])=><div key={label}><dt>{label}</dt><dd>{value}</dd></div>)}</dl><References ids={m.sourceIds}/></details>)}</div>{filtered.length===0&&<p>没有匹配项，可清空查找或切换数据类型。</p>}{filtered.length>12&&<button className="cn-action" onClick={()=>setExpanded(!expanded)}>{expanded?'收起为前12条':`展开全部${filtered.length}条`}</button>}<details className="cn-exclusions"><summary>4条不纳入规模主表的数值及其他排除说明</summary>{data.metrics.filter(m=>m.evidenceStatus==='排除主表').map(m=><article key={m.id}><h3>{m.metric}</h3><p>原记录：{showMetric(m)}；{m.period}。不用于全国人数、趋势图或市场计算。</p><p>{m.limitation}</p><References ids={m.sourceIds}/></article>)}<p>MoonFox列表中的月活标题未取得可核查的报告正文，未生成正式数值指标；微软2026中国切片未取得与全球方法一致的说明。来源列表保留这些访问或方法缺口。</p></details></section>;
}

export function ChinaAIUsers({navigate}:{navigate:(id:string)=>void}){return <article className="china-users">
 <header className="cn-heading"><h1>中国AI使用者规模与分层</h1><p className="cn-meta">研究截至2026年9月11日。全国最新可核验观察期：2025年12月；近期原生App监测：2026年6月。</p><div className="cn-downloads">{data.paymentSupplement&&<><button className="cn-action" onClick={()=>go('payers')}>查看付费用户数据 ↓</button></>}</div></header>
 <div className="cn-headline-stats"><div><strong>6.02<small>亿人</small></strong><span>全国生成式AI使用者</span><p>2025年12月 · 半年使用口径</p><References ids={['N24-S02']}/></div><div><strong>42.8<small>%</small></strong><span>占全国人口</span><p>分母是全国人口，不是网民</p><References ids={['N24-S02']}/></div><div><strong>4.99<small>亿</small></strong><span>原生App整体月活</span><p>2026年6月 · 第三方应用监测</p><References ids={['MB24-S01']}/></div></div>

 <ResearchOutline items={[...chapterGroups.map(g=>['cn-group-'+g.id,g.title] as [string,string]),['cn-ledger','指标台账'],['cn-sources','来源']]}/>
 {chapterGroups.map(group=><section className="cn-chapter" id={'cn-group-'+group.id} key={group.id}><h2>{group.title}</h2>{group.ids.map(id=>{const s=data.sections.find(x=>x.id===id)!;return <section id={`cn-${s.id}`} tabIndex={-1} className="cn-section" key={s.id}><h3>{s.title}</h3>{s.paragraphs.map((para,i)=><p className="cn-prose" key={i}>{['推断','假设','报告计算'].includes(para.kind)&&<span className="cn-kind">{para.kind}</span>}{para.text}<References ids={para.sourceIds}/></p>)}{s.id==='growth'&&<NationalChart/>}{s.id==='purpose'&&<PurposeChart/>}{s.id==='entry'&&<MobileChart/>}{s.tables.map(t=><DataTable key={t.title} table={t}/>)}{s.id==='ways'&&<Ways/>}{s.id==='tasks'&&<TaskProfiles/>}</section>;})}</section>)}


 <EvidenceLedger/>
 <section id="cn-sources" tabIndex={-1} className="cn-section cn-sources"><h2>全部来源与取证范围</h2><p>{data.referencesNote} {data.sources.length}个不同URL，包括原报告、官方摘要、方法说明和排除记录；并非同样数量的独立调查。</p>{data.sources.map(s=><details key={s.id}><summary>{s.title}<small>{s.publisher} · {s.publishedAt||'发布日期未注明'}</small></summary><div id={`cn-source-${s.id}`} tabIndex={-1}><p><a href={s.url} target="_blank" rel="noreferrer">打开原始页面 / PDF ↗</a></p><dl>{[['来源编号',s.id],['适用范围',s.scope],['方法及限制',s.method],['图表定位',s.locator]].map(([label,text])=><div key={label}><dt>{label}</dt><dd>{text}</dd></div>)}</dl></div></details>)}</section>
 <div className="cn-footer"><button onClick={()=>navigate('strategy')} className="cn-action">回到社区方案对照 →</button></div>
 </article>;}
