'use client';
import d from '@/lib/content-demand-depth.json';
import './content-demand-depth.css';
const base='/research-kit/douyin-method-2026-09-12/';
function Link({url,children}:{url:string;children:React.ReactNode}){return <a href={url} target="_blank" rel="noreferrer">{children} ↗</a>}
function Table({heads,rows}:{heads:string[];rows:React.ReactNode[][]}){return <div className="cd-table"><table><thead><tr>{heads.map(h=><th key={h}>{h}</th>)}</tr></thead><tbody>{rows.map((r,i)=><tr key={i}>{r.map((x,j)=><td key={j}>{x}</td>)}</tr>)}</tbody></table></div>}
const duration=(n:number|null)=>n===null?'未取得':`${Math.floor(Math.round(n)/60)}:${String(Math.round(n)%60).padStart(2,'0')}`;

export function DouyinDepth(){return <div className="dd-study" id="dd-study">
 <nav className="cd-toc" aria-label="作者与内容分析目录">{[['dd-reanalysis','样本复算'],['dd-authors','四位作者对照'],['dd-comments','具体反馈'],['dd-reference','参考方法'],['dd-keywords','搜索变化'],['dd-panel','后续研究']].map(([id,t])=><button className="cd-link" data-jump={id} key={id} onClick={()=>document.getElementById(id)?.scrollIntoView({block:'start'})}>{t}</button>)}</nav>
 <section id="dd-reanalysis"><h2>分类样本的分布与限制</h2><p>{d.lead}</p>
  <div className="dd-charts"><figure><figcaption>326位作者的样本深度</figcaption><div className="dd-stack" role="img" aria-label="311位作者只有一条，15位有两到三条"><span style={{width:`${311/326*100}%`}}>311</span><i style={{width:`${15/326*100}%`}} /></div><p>只有一条：311位 · 两到三条：15位</p><small>按作者编码去重；不是平台作者构成。</small></figure><figure><figcaption>336条可读时长作品的分布</figcaption>{d.stats.durationBins.map(b=><div className="dd-bar" key={b.label}><span>{b.label.replaceAll('<','少于')}</span><i style={{width:`${b.n/94*100}%`}} /><b>{b.n}</b></div>)}<small>另7条时长缺失。三分钟以下仅24条。</small></figure></div>
  <div className="de-findings">{d.findings.map(f=><article key={f.title}><div><h3>{f.title}</h3><p>{f.text}</p><p><strong>解释时要注意：</strong>{f.implication}</p></div></article>)}</div>
  <p className="de-meta">分类列表原字段未标指标名，统计统一使用“卡片可见计数”；只有详情已核对的读数标为点赞。显示“万”的数值按近似值计算。</p>
 </section>
 <section id="dd-authors"><h2>四位作者的连续作品与相反结果</h2><p>公开主页按现有案例和参考视频定向选取。58个详情已核对发布时间和可见互动，其中46条位于2026年7月13日至9月6日，另12条作为日期边界记录；没有将不同作者的绝对点赞数用于排名。</p><p className="de-meta">核对范围为详情页标题、说明、发布时间、时长及可见互动，58条均未完整观看；内容形式和资源承诺据标题与说明归纳，尚未验证成片质量、附件可用性或教学效果。</p>
  <Table heads={['作者','核对情况','窗口内／外','已核作品的八周分布']} rows={d.authors.map(a=>[<Link url={a.profileUrl} key={a.name}>{a.name}</Link>,a.coverage,`${a.inWindow}／${a.outside}`,<div className="dd-weekline" key={a.name} aria-label="每格标示自然周起始日期与已核发布数">{a.weeks.map(w=><span key={w.label} title={`${w.label}起的一周：${w.n}条已核作品，部分覆盖时不代表该周全部发布`}><small>{w.label}</small><b className={w.n>0?'filled':''}>{w.n>0?w.n:'—'}</b></span>)}</div>])}/>
  <p className="de-meta">“—”表示未核到该周作品，不自动视为停更；只有完整覆盖的可见清单才支持发布频次判断。各项互动均为9月12日读取的累计快照，作品年龄不同，不能恢复发表后第七天成绩。</p>
  {d.cases.map(c=><article className="dd-case" key={c.author}><span className="dd-author">{c.author}</span><h3>{c.title}</h3><p>{c.observed}</p><p>{c.interpretation}</p><dl className="de-fields"><div><dt>仍需解释</dt><dd>{c.counter}</dd></div><div><dt>社区需要考虑</dt><dd>{c.community}</dd></div></dl><div className="de-sources">{c.urls.map((url,i)=><Link key={url} url={url}>作品{i+1}</Link>)}</div></article>)}
  <details className="cd-profile"><summary><strong>58个详情逐条记录</strong><span>作者、日期、时长与四类互动</span></summary><div className="cd-profile-body">{d.authors.map(a=><div key={a.name}><h3>{a.name}</h3><Table heads={['内容','发布','时长','点赞','评论','收藏','分享','窗口']} rows={a.works.map(w=>[<Link key={w.url} url={w.url}>{w.title.slice(0,50)}</Link>,w.publishedAt,duration(w.durationSeconds),w.likeRaw??'未知',w.commentRaw??'未知',w.collectRaw??'未知',w.shareRaw??'未知',w.inWindow?'内':'外'])}/></div>)}</div></details>
 </section>
 <section id="dd-comments"><h2>评论里提出了哪些具体问题</h2><p>两件作品各重新读取默认排序的前五条评论，匿名归纳如下。判断依据包括用户看过什么、报告了什么失败，以及是否收到后续回应。</p>
 {d.observations.sources.map(s=><article className="dd-case" key={s.url}><h3><Link url={s.url}>{s.author} · {s.author==='foyege'?'多人控场方法':'课文与历史叙事'}</Link></h3><Table heads={['可见顺序','评论归纳','关注点']} rows={s.comments.map(c=>[c.position,c.paraphrase,c.kind])}/><p>{s.inference}</p></article>)}
 <p className="de-meta">这张表只列两件作品的十条顶层记录，不代表十位独立用户。扩展评论和作者回复见上文“作品互动与评论证据”；历史数字分歧仍未作为已核实史实。</p>
 </section>
 <section id="dd-reference"><h2>参考视频怎样分组和比较作品</h2><p><Link url={d.reference.url}>{d.reference.title}</Link>，{d.reference.author}，{d.reference.publishedAt}。</p><Table heads={['视频位置','方法','图表实际做法','本研究如何使用']} rows={d.reference.methods.map(m=>[m.time,m.method,m.shown,m.adopt])}/><p className="de-meta">{d.reference.reviewDepth}</p><p>这一方法结合分组、时间与反例比较作品。作者提出的时长、昵称或标签建议仍是样本中的经验解释，不能直接套用为社区增长规律。</p></section>
 <section id="dd-keywords"><h2>32个关键词的搜索变化</h2><p>全国／抖音，2026年8月10日至9月10日；四组都展示，避免只选择上涨案例。同比与环比沿用平台原定义，分母为查到实值的32个精确词。</p><div className="dd-quadrants">{[...d.stats.quadrants].sort((a,b)=>a.quadrant.localeCompare(b.quadrant)).map(q=><article key={q.quadrant}><h3>{q.quadrant}<b>{q.n}词</b></h3><p>{q.keywords.join('、')}</p></article>)}</div><p>“历史人文”同时增长，但平均搜索指数为417；它与“历史”不是相同搜索范围。先看用户表达的具体问题，再比较同义词与连续时间。指数不是搜索人数，单次榜单的视频量也不能作为同窗口新增供给分母。</p></section>

 <section id="dd-panel"><h2>作者八周作品清单仍需补齐</h2><p>四位作者的连续作品核对和51位作者的63件互动快照，解决的是不同问题。六类入口、48位作者的八周完整作品清单尚未收全；不能用作者身份数替代面板完成数。</p><Table heads={['作者入口层','消费对象','纳入时要保留的差异']} rows={d.layers}/><ol><li><strong>先补样本选择和完整性。</strong>记录查询词、排序和纳入顺序；加入普通行业作者、短内容及AI用法未知者。样本已包含普通检索和分类入口，但完整窗口、短内容与中尾部作者的覆盖仍需核对。</li><li><strong>按作者、作品和日期建立关联。</strong>分别记录新内容、同集版本、合集和推广。看完选定详情后再编码主题、表达方式与AI生产环节。</li><li><strong>比较正常表现与反例。</strong>在同作者、相近题材、相近作品年龄下比较分布，保留相反结果；没有曝光与历史粉丝值就不补算转化或涨粉归因。</li><li><strong>沿评论追踪问题有没有解决。</strong>检查具体条件、作者回复与后续作品；从未满足诉求回查竞品供给，而不是用搜索结果少替代供给不足。</li></ol><p>完整方案包含采样规则、字段表、时间窗口、评论选取、作品年龄处理与停止条件。现有证据限于竞品和内容观察，不包含达人招募或社区试运营结果。</p></section>
 </div>}

export function DepthPlanning(){return <section id="dd-opportunity"><h2>从抖音消费到社区机会，还需要证明什么</h2><Table heads={['观察线索或待检验情形','还缺什么','下一步核对','何时不能成立']} rows={d.opportunity.map(x=>[x.signal,x.missing,x.question,x.stop])}/><p>对多元拾光，内容需要让外部用户愿意再次观看、查阅、讨论或使用。工具可以支持其中一部分供给，但生成次数、作者发文数和履约互动均不能替代外部用户的持续有效活跃。</p><p>抖音已有成熟的分发与观看入口。社区若主张提供出处、源文件、系列讨论或适用条件，必须先查清这些材料是否缺失、谁能持续维护，以及用户为什么需要在这里继续。这些是待验证的价值，不是已经选定的方向。</p></section>;}
