import type { Profile, Source } from './research-types';
const s=(title:string,url:string,date:string,note:string,type='官方'):Source=>({title,url,date,note,type});
export const developerProfiles: Profile[] = [
{
 id:'huggingface',name:'Hugging Face',group:'开发与应用',focus:'可运行资产 · 围绕资源协作',thesis:"Hugging Face关联模型卡、演示、版本与讨论，使用者可在资源旁查看输入、限制和问题处理记录。",
 job:'模型使用者、研究者与开发者发现、验证、部署和改进 AI 能力。',object:'模型、数据集、Spaces、模型卡、讨论与 PR',first:'按任务找资源 → 读模型卡／试 Demo → 复制或使用 → 报问题／改进',supply:'模型／数据／演示作者、组织贡献和开源协作；部分资源支持',repeat:'项目依赖、版本更新、问题解决与共同维护（机制推断）',business:'资源托管、推理与付费账户；免费使用和创建条件区分',relevance:"输入输出、依赖、版本与作者责任",notCopy:'全球模型仓库、GPU 托管与研究生态。',experiment:"将 3 个资源整理成有用途、状态、来源和关联讨论的小专题，记录查阅、收藏回看、问题跟进与试用；可运行承诺另核依赖和结果。",access:'Hub 文档、历史博客和研究论文可读；创建／复制付费条件已交叉复核，未实际部署或调用。',
 sections:[
 {title:'协作围绕具体资源发生',status:'事实',paragraphs:['Hub 的模型、数据集与 Spaces 都是可持续维护的资产；每个仓库可有讨论和 PR，另有全站论坛。模型卡承载用途、评估、限制等，帮助使用者在运行前理解是否适合。','这区别于泛问题信息流：讨论关联具体版本与资源，后续使用者有机会复用答案。作者也能通过使用反馈修正说明和产物。'],refs:[3,4]},
 {title:'首次有效使用的实际前提',status:'事实',paragraphs:['Spaces 文档给出公开应用、源码、复制及硬件设置的关系。复制后可能需要重新配置服务和秘密信息；Protected 应用可以公开使用，但其他人不能克隆其源码。','当前创建／复制计算型 Space 有付费计划条件，并有明确免费例外；静态 Space 与运行别人应用也应分别看。不能把历史“免费 Demo”概括成任何人都能免费托管全部应用。'],refs:[1,2]},
 {title:'历史起点不是一个空壳社区',status:'历史',paragraphs:['2021 年官方回顾在已有模型资源基础上推出 Spaces，并通过合作实践活动增加模型、数据与演示。历史意义在于已有可用资产与开发者参与，而非先等大家自发闲聊。','活动规模数字属于当时自报，不能当作当前活跃，更无法分离活动、模型生态与免费资源对增长的贡献。'],refs:[5]},
 {title:'回访与商业承接',status:'推断',paragraphs:['资源进入项目后，版本变化、效果调整与排错都可能带来回访；作者也可能获得展示、声誉和使用反馈。这是项目使用的一种解释，现有资料不能排除单独查资料、跟进讨论或学习的回访。','推理、硬件、团队与账户条件承接商业价值。免费硬件休眠、配额和创建条件说明持续可用有成本；不能把资源数或下载次数等同于成功使用。'],refs:[1,2]},
 {title:'UI／UX 与反证',status:'边界',paragraphs:['模型卡、任务分类、在线演示和相关讨论构成清晰的信息关系。2024 年研究也记录使用者在理解模型、输出与新手指导方面的困难，说明资源丰富仍可能难以选择和使用。','这项研究来自历史样本，不是 2026 年故障率。对多元拾光更直接的验证，是新人是否看得懂一个案例的适用条件，是否知道失败后该补什么。'],refs:[4,6]},
 {title:"资源说明与维护的适用条件",status:'建议',paragraphs:['可参考资源运行、说明与问题跟进的组织方式。多元拾光的 Token 服务可支持部分应用试用，范围按具体任务确定；MakeNow 案例也需相应说明与维护。']}
 ],gaps:['模型／Space 数量中的可用和活跃比例未核。','官方资源支持对长期贡献的净作用，资料不足。','创建、配置、运行与跨账户复制未执行。'],sources:[s('Spaces Overview','https://huggingface.co/docs/hub/spaces-overview','访问 2026-09-08','创建、复制、可见性和资源条件，已交叉复核'),s('Spaces ZeroGPU','https://huggingface.co/docs/hub/spaces-zerogpu','未标更新日','免费例外、队列与运行边界'),s('Pull Requests & Discussions','https://huggingface.co/docs/hub/en/repositories-pull-requests-discussions','未标更新日','围绕资源协作'),s('Model Cards','https://huggingface.co/docs/hub/model-cards','未标更新日','用途、评估、限制与发现'),s('Summer at Hugging Face','https://huggingface.co/blog/summer-at-huggingface','2021-09-24','Spaces 与合作实践的历史自述'),s('Hugging Face 社区使用问题研究','https://arxiv.org/abs/2401.13177','2024-01-24；SANER 2024','历史研究样本，未当作当前错误率','研究论文')]
},
{
 id:'modelscope',name:'魔搭 ModelScope',group:'开发与应用',focus:'模型到项目 · 技术供给与产业支持',thesis:"魔搭结合开放模型、运行环境与指导活动，依托企业和技术机构供给。新社区采用类似模式时，仍需独立核算算力及维护。",
 job:'AI 开发者与研究者选择模型、实验、部署并分享技术成果。',object:'模型、数据、Notebook、创空间、技术文章和活动',first:'找模型／项目 → Notebook 或创空间运行 → 改输入 → 上传／分享',supply:'机构模型、开发者项目与技术文章；贡献评审和阶段性激励',repeat:'实验迭代、技术问题和模型版本（机制推断）',business:'免费体验、算力与服务体系并存；活动资源有资格和期限',relevance:"内容复现条件与评审工作",notCopy:'机构模型供给、训练平台及规模化算力扶持。',experiment:"编选一组可持续维护的资源与学习材料，观察用户查阅、回看更新、提问和选用；资源质量按说明准确、维护及时衡量，运行用户另验输出。",access:'官方文档、部分搜索正文及集团发布可核；魔搭动态文章直开有空壳／超时，项目未运行。',
 sections:[
 {title:'围绕开发过程聚合内容',status:'事实',paragraphs:['2026 年更新的新手文档连接模型下载、实验、训练及上传分享；Notebook 与创空间让内容可以带运行环境。它既有技术学习，也有模型和应用资产。','阅读资料后可进入实验环境，但使用者仍需理解模型与环境配置。现有观察没有验证非技术创作者能否顺利完成这条路径。'],refs:[1,2]},
 {title:'历史资产和机构支持',status:'历史',paragraphs:['阿里巴巴 2022 年发布材料说明，魔搭上线时已经带着多年研发积累的模型资源。这样的起点包含团队技术、机构信誉与供给，不能概括为搭好社区等用户上传。'],refs:[5]},
 {title:'作者评审重视可复现',status:'事实',paragraphs:['当前技术征文相关说明强调方法、文件、问题解决、比较与可复现性，官方质量评审的权重高于浏览和社交表现。这提供了一种值得研究的内容选择逻辑。','历史贡献勋章以贡献类别安排资源和合作权益，但所读第五期权益已经到期；不应把旧获奖资源视为现在都可申请。'],refs:[3,4]},
 {title:'运行环境和资源的限制',status:'边界',paragraphs:['xGPU 有试用和资源生命周期条件，旧活动的免费 GPU 数额不能当作当前全员权益。历史共享应用教程甚至提醒读者复制到自己空间，以免共享写入影响其他人。','可访问项目页面不等于项目正在运行；引用旧演示浏览量也不能证明当前可用。复制说明必须告诉使用者需要什么数据、环境和独立配置。'],refs:[2,6,7]},
 {title:'复访与产品启发',status:'推断',paragraphs:['持续实验和维护可能带来资源查阅、问题处理和更新跟进；公开活动参与不能直接证明常态互助。']}
 ],gaps:['当前所有活动开放资格与有效期未逐一核验。','开发者留存、独立贡献占比与激励 ROI，资料不足。','拼豆内置示例完成一次转换；模型推理、下载、MCP连接和空间部署结果未实测。'],sources:[s('模型使用与新手文档','https://www.modelscope.cn/learn/434243?lang=en_US','更新 2026-07-02','运行与上传路径；索引可读、直开空壳'),s('创空间 xGPU','https://modelscope.cn/docs/studios/xGPU','未标更新日','资源与试用条件'),s('第五期贡献勋章权益','https://www.modelscope.cn/learn/434850','更新 2026-07-10；权益至 08-06','已结束的贡献支持'),s('我的云端 AI 工作站征文','https://www.modelscope.cn/learn/435841','访问 2026-09-08；精确发布日期未核','质量、可复现与传播评审；索引读取'),s('Alibaba 发布 ModelScope','https://www.alibabagroup.com/en-US/document-1525026652642344960','2022-11-03','模型积累与上线历史','官方集团发布'),s('历史 Langflow 创空间教程','https://community.modelscope.cn/67ee69925987ff6c2332021f.html','约 2025；精确日期未核','共享与独立空间的使用边界','平台社区教程'),s('历史 UniDiffuser 创空间示例','https://modelscope.cn/studios/thu-ml/unidiffuser','旧项目；当前运行未测','页面存在不等于可运行')]
},
{
 id:'dify',name:'Dify 社区',group:'开发与应用',focus:'从真实工作流到模板 · 维护责任',thesis:"Dify把可运行应用整理成可导入模板，使用者仍需配置和修改。可比较的是方法交接的材料、步骤及支持责任。",
 job:'应用构建者、团队和开发者把 AI 用于具体业务任务。',object:'应用、工作流模板、插件、作者主页与问题协作',first:'找任务模板 → 看结构 → Open in Dify → 配置 → 用自己的输入运行',supply:'官方／伙伴／社区模板与插件；作者展示及可选引荐订阅佣金',repeat:'应用运行、问题修复、需求迭代与版本维护（机制推断）',business:'Cloud 有试用额度；自部署与企业版分开；接自有外部模型时费用另计',relevance:"模板交接、所需配置与作者支持",notCopy:'模板商城、分销结算、企业平台与完整插件生态同步建设。',experiment:"围绕一个应用用途整理方法、版本和真实问题记录，观察读者的持续查阅、交流与复用；模板接手按其承诺检查，不要求所有用户运行。",access:'2026 Creator Center 公告、应用管理、插件规则和价页可读；未导入或运行模板，未绑定作者佣金。',
 sections:[
 {title:'2026 年模板生态已经变化',status:'事实',paragraphs:['3 月 Creator Center 介绍时，Studio 直接发布仍属于后续计划；5 月正式公告已经说明可从 Studio 发布到 Marketplace。模板详情提供结构预览、作者和导入入口，目标是降低空白画布与手工讲解成本。','这说明分享应接在真实工作流之后。但导入成功不等于任务成功，用户还需要自己的数据与模型服务。'],refs:[1,2,3]},
 {title:'作者价值与付费边界',status:'事实',paragraphs:['作者可以通过模板和作品集获得曝光与机会，并选择绑定 Affiliate，在引荐用户订阅时获得佣金。这不是按下载或每次运行自动付给所有模板作者的收益。','插件是另一种供给对象。规则要求独特功能、端到端可用、完整配置文档和持续支持；现行协议仍限定免费插件，插件调用外部付费服务可以另有费用。'],refs:[2,4,7]},
 {title:'维护才是供给的一部分',status:'事实',paragraphs:['官方插件规则反对重复换皮和无意义更新；作者应提供支持、修复问题，失联可能导致限制安装或下架。复制模板的 DSL 也不带第三方凭证、知识库内容和使用日志。','复制按钮不会补齐凭证、数据和使用环境；模板能够导入，也不意味着后来者已经具备运行条件。'],refs:[3,4]},
 {title:'历史工具与开发者起点',status:'历史',paragraphs:['2023 年官方开源公告回溯 Cloud 先上线，核心已经包含可视化提示、上下文数据、应用发布与日志改进。它先提供构建工具，再借开源发展参与者。','当时自报的应用数量不用于证明当前社区规模。当前开源许可也不能沿用最早公告的文字，故本报告不据历史许可提出商业复制建议。'],refs:[6]},
 {title:"重复使用与适用任务",status:'推断',paragraphs:['真实应用运行、效果问题、外部 API 变化和用户需求会带来复访；这首先是工具和维护价值。论坛、模板和作者关系是否增加留存，仍缺公开分群数据。'],refs:[5]}
 ],gaps:['模板导入后首效和长期留存未公开。','引荐佣金的作者实际收益与供给质量相关性，资料不足。','已验证UTM代码模板的一次运行与未发布副本保存；模型调用、插件安装和依赖配置未实测。'],sources:[s('Creator Center 正式上线','https://dify.ai/blog/build-share-earn-dify-creator-center-and-template-marketplace-are-now-live','2026-05-19','正式发布、结构预览与 Studio 发布'),s('Creator Center 早期介绍','https://dify.ai/blog/dify-creator-center-template-marketplace-share-your-workflows','2026-03-10','作者主页、引荐佣金及当时计划状态'),s('Manage Apps','https://docs.dify.ai/en/cloud/use-dify/workspace/app-management','更新 2026-07-29','复制、DSL 与不携带的内容'),s('Plugin Development Guidelines','https://docs.dify.ai/en/develop-plugin/publishing/standards/contributor-covenant-code-of-conduct','未标更新日','独特性、质量与作者维护'),s('Pricing','https://dify.ai/pricing','访问 2026-09-08','Cloud、自部署与 Enterprise 边界'),s('Dify 开源公告','https://dify.ai/blog/dify-open-source','2023-05-15','早期工具与开发者参与；不采用旧许可为现状'),s('Marketplace Agreement','https://www.dify.ai/legal/marketplace-agreement','更新 2025-06-09','免费插件与外部付费披露')]
},
];
