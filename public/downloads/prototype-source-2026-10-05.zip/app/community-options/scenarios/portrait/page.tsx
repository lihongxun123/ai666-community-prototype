import Link from '@/components/research-link';
import '../../cases/ecommerce/style.css';
const A = ({ href, children }: { href: string; children: React.ReactNode }) => (
  <a href={href} target="_blank" rel="noopener noreferrer">
    {children} ↗
  </a>
);
const rows = [
  [
    '确认',
    '原片权属、保留特征、允许修改范围',
    '写脸部、发型、服饰和记忆线索',
    '确认清单',
    '本人或知情者同意范围',
  ],
  [
    '准备',
    '原片、可靠辅助参考、公开选择',
    '区分原片、参考和推测材料',
    '素材与权限说明',
    '无依据区域标记缺失',
  ],
  [
    '处理',
    '污损、曝光或局部缺失',
    '从局部开始，记录范围和方法',
    '候选图与区域说明',
    '未改动禁区',
  ],
  [
    '核对',
    '原片、候选、确认清单',
    '分别检查清晰度与相似度',
    '核对意见',
    '知情者能说明保留项',
  ],
  [
    '交付',
    '采用图、用途、公开范围',
    '确认采用或保留原片，附说明',
    '成片与说明',
    '用途、权限和推测内容明确',
  ],
];
export default function Page() {
  return (
    <main className="ec-study">
      <header>
        <Link href="/community-options/scenarios">← 九类场景</Link>
        <span>人像与生活影像 · 专题方案</span>
      </header>
      <h1>纪念影像先保留熟悉的人，再谈清晰度</h1>
      <p className="ec-lead">
        修复只是纪念影像的一个子任务。相似度由本人、亲属或熟悉人物者确认；没有依据的细节保持缺失或标为推测。
      </p>
      <nav>
        {[
          ['evidence', '依据'],
          ['task', '主任务'],
          ['branch', '差异任务'],
          ['supply', '供给'],
          ['recovery', '中断与复用'],
          ['scope', '责任与边界'],
        ].map(([id, t]) => (
          <a key={id} href={'#' + id}>
            {t}
          </a>
        ))}
      </nav>
      <section id="evidence">
        <h2>原作者的反馈能说明确认者的重要性</h2>
        <article>
          <small>
            Reddit 原作者求助及回复 · 页面显示约 5 个月前，核读 2026-09-20
          </small>
          <p>
            发帖者说自动处理改变了旧人像面貌。分层混合和修补建议获其认可，理由是保留真实特征；另一份结果被评价为不像原人物，制作者说明未使用
            AI。该讨论说明要由知情者核对身份，不能把每个错误归因于
            AI，也不是独立视觉验收。
          </p>
          <A href="https://www.reddit.com/r/photorestore/comments/1sqk7x8/portrait_restoration_looking_for_tools_or_help_ai/">
            查看原帖与反馈
          </A>
        </article>
      </section>
      <section id="task">
        <h2>主任务：一张可确认的纪念影像</h2>
        <div className="ec-flow">
          确认保留项 → 选择原片与参考 → 小范围处理 → 并排核对 → 知情者确认 →
          导出说明
        </div>
        <div className="ec-scroll">
          <table>
            <thead>
              <tr>
                <th>环节</th>
                <th>输入</th>
                <th>动作</th>
                <th>产物</th>
                <th>完成检查</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r[0]}>
                  {r.map((c) => (
                    <td key={c}>{c}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section id="branch">
        <h2>差异任务</h2>
        <div className="ec-three ec-choice">
          <article>
            <h3>旧照局部修复</h3>
            <p>
              输入污损位置和可靠参考；先修复可证实部分。产物为局部前后、方法和不确定项；完成检查是修复没有改变相似度。
            </p>
          </article>
          <article>
            <h3>风格写真</h3>
            <p>
              输入本人授权参考、必须保留的身份项、可变造型和场景、用途；并列候选后由本人采用。完成检查是身份项未被造型覆盖，适用用途明确。当前缺完整公开过程。
            </p>
          </article>
          <article>
            <h3>纪念排版</h3>
            <p>
              输入已确认影像、文字和尺寸；组织画面而不重新定义人物。产物为预览、文字来源和尺寸；完成检查是知情者确认成片和用途。
            </p>
          </article>
        </div>
      </section>
      <section id="supply">
        <h2>内容样本及最低材料</h2>
        <div className="ec-scroll">
          <table>
            <thead>
              <tr>
                <th>内容</th>
                <th>最低材料</th>
                <th>卡片动作</th>
              </tr>
            </thead>
            <tbody>
              {[
                [
                  '保留项怎样写清',
                  '演示图、确认清单、公开选择',
                  '查看确认条件',
                ],
                [
                  '污损局部怎样处理',
                  '局部前后、范围、方法与不确定项',
                  '看问题区域',
                ],
                ['清晰与相似怎样分别核对', '原片、候选、采用理由', '比较核对'],
                [
                  '纪念排版怎样不覆盖原片',
                  '确认影像、文字出处、尺寸',
                  '看排版条件',
                ],
                [
                  '私密影像如何求助',
                  '允许公开局部、问题和期望',
                  '查看匿名方法',
                ],
              ].map((r) => (
                <tr key={r[0]}>
                  {r.map((c) => (
                    <td key={c}>{c}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
      <section id="recovery">
        <h2>中断恢复与二次使用</h2>
        <ul>
          <li>面貌被改：退回原片，只处理更小范围，再由知情者核对。</li>
          <li>
            细节没有依据：标为推测修补或保留缺失，不用流畅画面替代历史事实。
          </li>
          <li>家人意见不同：并列原片与候选，记录担心的特征，不直接覆盖。</li>
          <li>纪念排版复用已确认成片和公开选择；换用途须重新确认范围。</li>
        </ul>
      </section>
      <section id="scope">
        <h2>责任、工具与证据边界</h2>
        <div className="ec-two">
          <article>
            <h3>使用者与知情者</h3>
            <p>
              使用者提供有权使用的原片、允许范围和用途；本人、亲属或熟悉人物者决定是否采用。
            </p>
          </article>
          <article>
            <h3>编辑</h3>
            <p>
              编辑只收集获授权演示素材，分别标注修复、写真和纪念排版；没有许可时只保留脱敏方法。
            </p>
          </article>
        </div>
        <p>
          MakeNow
          已有画布；上传、隐私范围、编辑、项目复制和导出均未核实。当前只有一条带原作者反馈的修复过程；写真与纪念排版仍缺完整过程和授权资产，不能判断真实供给或普遍效果。
        </p>
      </section>
      <footer>
        来源核读：2026-09-20。专题方案尚未验证真实上传、修图、生成、发布或工具集成。
      </footer>
    </main>
  );
}
