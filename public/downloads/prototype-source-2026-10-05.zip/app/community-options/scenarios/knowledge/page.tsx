import Link from '@/components/research-link';
import '../../cases/ecommerce/style.css';
const rows = [
  ['定题', '问题、读者、使用时刻', '任务卡与不回答范围', '问题/读者缺失不检索'],
  [
    '资料包',
    '原文、作者、日期、许可',
    '来源卡与冲突清单',
    '核心结论可回到原文',
  ],
  ['解释', '事实、推断、未知分开', '提纲与图注文案', '推断不得伪装为事实'],
  ['图文', '术语、数据、图片依据', '解释图文初稿', '每张图承担一个解释任务'],
  [
    '核对发布',
    '链接、引用、版权、读者问题',
    '成稿与勘误记录',
    '逐项核读后才发布',
  ],
];
export default function Page() {
  return (
    <main className="ec-study">
      <header>
        <Link href="/community-options/scenarios">← 九类场景</Link>
        <span>知识内容创作 · 专题方案</span>
        <h1>把资料讲清楚，也让读者找得到出处</h1>
        <p className="ec-lead">
          主任务是将一组可追溯材料交给明确读者作理解或判断；不是把大纲直接变成成稿。科学阅读重在数据条件与证据等级，历史表达重在史料出处与推测边界。
        </p>
        <nav>
          <a href="#evidence">证据</a>
          <a href="#task">路径</a>
          <a href="#content">内容卡</a>
          <a href="#delivery">交付</a>
        </nav>
      </header>
      <section id="evidence">
        <h2>资料整理有参照，完整中文发布过程仍缺</h2>
        <article>
          <small>中文作者方法复盘 · 2026-01-09 · 部分过程</small>
          <h3>资料太多会让结构失焦</h3>
          <p>
            少数派作者以设计趋势调查为例，限定来源、制作思维导图并删减材料，再用问答、Markdown
            和提纲组织输入；未附最终知识成稿和逐条核验。
          </p>
          <a
            href="https://sspai.com/post/105303"
            target="_blank"
            rel="noopener noreferrer"
          >
            查看原文 ↗
          </a>
        </article>
        <article>
          <small>中文作者学习过程 · 2026-01 · 个人采用自述</small>
          <h3>课程任务先限定高信噪比资料</h3>
          <p>
            一位 CS 学生只把 Lecture Slides、Tutorial Notes 和 Assignment Spec
            放入课程资料库，并要求优先依据它们回答；研究报告先选论文、核对格式、再规划与生成。未提供完整提交物或评分。
          </p>
          <a
            href="https://sspai.com/post/105374"
            target="_blank"
            rel="noopener noreferrer"
          >
            查看原文 ↗
          </a>
        </article>
        <article>
          <small>Google 官方展示 · 2026-05-27</small>
          <h3>NotebookLM 把来源和多种成品放在同一个项目</h3>
          <p>
            Google I/O 公开 notebook
            集合演讲、演示和博客，展示来源问答、音频、演示稿、信息图与视频；页面也提示生成可能不准确。它是厂商展示，不是用户成效。
          </p>
          <a
            href="https://blog.google/innovation-and-ai/products/notebooklm/notebooklm-google-io-2026/"
            target="_blank"
            rel="noopener noreferrer"
          >
            查看说明 ↗
          </a>
        </article>
        <p>
          <strong>判断：</strong>
          新过程支持把资料筛选、来源隔离和提交格式设为前置完成检查；仍不能声称已有中文创作者从选题到发布、更正的完整采用样本。
        </p>
      </section>
      <section id="task">
        <h2>主任务：一篇有出处的解释图文</h2>
        <div className="ec-flow">
          明确问题 → 建资料包 → 搭解释骨架 → 制作图文 → 逐项核对 → 发布与更正
        </div>
        <div className="ec-scroll">
          <table>
            <thead>
              <tr>
                <th>环节</th>
                <th>输入与动作</th>
                <th>产物</th>
                <th>完成检查</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r[0]}>
                  {r.map((c) => (
                    <td key={c}>{c}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="ec-two">
          <article>
            <h3>科学阅读分支</h3>
            <p>
              记录定义、数据口径和证据等级；核心机制存疑时由具备相应专业能力的人复核后再发布。
            </p>
          </article>
          <article>
            <h3>历史叙事分支</h3>
            <p>
              逐项对应时间、人物与物件出处；争议解释并列，创作性复原画面单独说明。
            </p>
          </article>
        </div>
      </section>
      <section id="content">
        <h2>内容卡要说明最低材料与读者动作</h2>
        <div className="ec-scroll">
          <table>
            <thead>
              <tr>
                <th>选题</th>
                <th>最低材料</th>
                <th>使用者继续做什么</th>
              </tr>
            </thead>
            <tbody>
              {[
                [
                  '设计趋势来源地图',
                  '至少三篇原文、日期、术语差异',
                  '区分原话与二次概括',
                ],
                [
                  '一张机制科普图',
                  '原始研究/权威说明、数据口径、目标年龄',
                  '指出图中每一步出处',
                ],
                [
                  '史料卡时间线',
                  '出处、时间、地点、争议点',
                  '分开读已证实与推测',
                ],
                [
                  '规范更新简报',
                  '现行原文、版本/生效日期、适用范围',
                  '找到影响自己的条款',
                ],
              ].map((r) => (
                <tr key={r[0]}>
                  {r.map((c) => (
                    <td key={c}>{c}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="ec-three ec-choice">
          <article>
            <h3>解释案例卡</h3>
            <p>核心问题、适合读者、来源状态与关键修改。</p>
          </article>
          <article>
            <h3>来源包卡</h3>
            <p>选取理由、定位、日期、许可和未解决冲突。</p>
          </article>
          <article>
            <h3>勘误讨论卡</h3>
            <p>具体说法、依据、作者回复和受影响内容。</p>
          </article>
        </div>
      </section>
      <section id="delivery">
        <h2>发布后仍要能纠正</h2>
        <p>
          作者承担问题、材料与解释；编辑核对引用、日期和内容状态；使用者以实际问题检验是否看懂。链接失效、出处冲突、图片不符或授权不明时退回资料包，标为待补来源/许可，不以流畅文案补洞。
        </p>
        <p>
          <strong>二次使用：</strong>
          来源卡、术语表、图注模板、勘误记录与受众骨架可复用；换平台或资料更新后重新核读原文。NotebookLM、课程资料库和文档编辑器已有按来源提问、分资料包和修订文本等组织方式；不表示社区已接入。
        </p>
        <p>
          <strong>MakeNow 边界：</strong>
          只确认用户可在自有画布确认视觉稿。检索、引用核验、长文编辑、版本管理、文件导入导出和演示交付均未知；本页是内容任务与人工放行链，不是功能承诺。
        </p>
      </section>
      <footer>
        来源核读：2026-09-20。专题不要求自建知识生成或专业审稿工具。
      </footer>
    </main>
  );
}
