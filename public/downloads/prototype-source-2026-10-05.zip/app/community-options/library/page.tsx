import Link from '@/components/research-link';
import '../options.css';
const groups=[
 ['当前方向依据',[['/community-options/review','机会与已有替代'],['/community-options/scenarios','九类场景研究'],['/research-decisions/tasks','任务证据']]],
 ['内容与产品参照',[['/community-options/content-system','内容组织'],['/community-options/cases/ecommerce','电商营销案例'],['/community-options/cases/ecommerce/journey','电商制作路径'],['/community-options/background','近期应用变化'],['/community-options/home-draft','首页内容草案'],['/community-options/product-sample','产品样板']]],
 ['证据状态与能力记录',[['/research-status','证据状态'],['/community-options/freshness','工具能力核查']]],
 ['历史方案',[['/community-options/themes/decision','历史主题取舍'],['/community-options/briefs','早期五套方案']]],
] as const;
export default function Page(){return <main className="op-shell"><header className="op-top"><Link href="/community-options">← 五套方案</Link><Link href="/#overview">研究总览</Link></header><section className="op-hero"><span>社区方案 / 依据</span><h1>结论背后的材料</h1><p>按研究主题查阅来源、案例与比较。产品概念图中的人物、数据和效果为设计示例；功能描述为规划，实际能力以产品验证为准。</p></section>{groups.map(([title,links])=><section className="op-section" key={title}><h2>{title}</h2><div className="op-table"><table><tbody>{links.map(([href,label])=><tr key={href}><th>{label}</th><td><Link href={href} target="_blank" rel="noopener noreferrer">打开资料 ↗</Link></td></tr>)}</tbody></table></div></section>)}</main>}
